<?php
/**
 * Single Event Template
 * A single event. This displays the event title, description, meta, and
 * optionally, the Google map for the event.
 *
 * Override this template in your own theme by creating a file at [your-theme]/tribe-events/single-event.php
 *
 * @package TribeEventsCalendar
 * @version  4.3
 *
 */



if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$events_label_singular = tribe_get_event_label_singular();
$events_label_plural = tribe_get_event_label_plural();

$event_id = get_the_ID();
$done = array();


if(isset($_REQUEST['acf'])){
	
	/* Si la variable existe, on ajoute le post à la liste des mises à jour à faire */
	
	$option_name = 'events-to-update';
	$current_array = get_option($option_name);
	$current_array[$event_id] = mktime();
	update_option( $option_name, $current_array );
	
	
	if(isset($_REQUEST['acf']['field_5939ced2dcd39'])){
		if($_REQUEST['acf']['field_5939ced2dcd39']  == 1){

			/* Actions à faire si l'évènement est terminé */
			$transient_name = 'asttq_p_table_'.$event_id;
			delete_transient($transient_name);
		}  
	}else{
		
	}
}

?>

<div id="tribe-events-content" class="tribe-events-single">

	<p class="tribe-events-back">
		<a href="<?php echo esc_url( tribe_get_events_link() ); ?>"> <?php printf( '&laquo; ' . esc_html_x( 'All %s', '%s Events plural label', 'the-events-calendar' ), $events_label_plural ); ?></a>
	</p>

	<!-- Notices -->
	<?php tribe_the_notices() ?>

	<?php the_title( '<h1 class="tribe-events-single-event-title">', '</h1>' ); ?>

	<div class="tribe-events-schedule tribe-clearfix">
		<?php echo tribe_events_event_schedule_details( $event_id, '<h2>', '</h2>' ); ?>
		<?php if ( tribe_get_cost() ) : ?>
			<span class="tribe-events-cost"><?php echo tribe_get_cost( null, true ) ?></span>
		<?php endif; ?>
	</div>

	<!-- Event header -->
	<div id="tribe-events-header" <?php tribe_events_the_header_attributes() ?>>
		<!-- Navigation -->
		<h3 class="tribe-events-visuallyhidden"><?php printf( esc_html__( '%s Navigation', 'the-events-calendar' ), $events_label_singular ); ?></h3>
		<ul class="tribe-events-sub-nav">
			<li class="tribe-events-nav-previous"><?php tribe_the_prev_event_link( '<span>&laquo;</span> %title%' ) ?></li>
			<li class="tribe-events-nav-next"><?php tribe_the_next_event_link( '%title% <span>&raquo;</span>' ) ?></li>
		</ul>
		<!-- .tribe-events-sub-nav -->
	</div>
	<!-- #tribe-events-header -->

	<?php 
			if(is_user_logged_in() && current_user_can('manage_options')){
				if(isset($_POST['acf'])){
					//unset($_POST);
					echo '<!-- Post just saved  -->';
					echo do_shortcode('[edition_positions]');
				}else{
					echo '<!-- No post data! -->';
					echo do_shortcode('[edition_positions id="'.$event_id.'"]');
				}
				
			}
	
	
	while ( have_posts() ) :  the_post(); ?>
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<!-- Event featured image, but exclude link -->
			<?php echo tribe_event_featured_image( $event_id, 'full', false ); ?>

			<!-- Event content -->
			<?php do_action( 'tribe_events_single_event_before_the_content' ) ?>
			<div class="tribe-events-single-event-description tribe-events-content">
				<?php 
	
					$classementHeader = '[learn_more caption="Résultats"]';
					
					$event_id = icl_object_id($event_id, 'tribe_events', true,'fr');
					
					$classementFinal = get_points_table_for_event($event_id);
			
					//var_dump($competitions);
			
					the_content(); 
					$terms = get_the_terms( get_the_ID(), 'classes' );
					
					
					$classes = '[learn_more caption="Classes" state="open"]';		
					
					
			
					foreach($terms as $term){
						$classes .= '<h4>'.$term->name.'</h4>';
						if(!in_array($term->term_id,$done)){
						
						
								$classement .= '<h3>'.$term->name.'</h3>';
								
								$tireurs = get_posts(array(
								  'post_type' => 'tireurs',
								  'numberposts' => -1,
								  'tax_query' => array(
									array(
									  'taxonomy' => 'classes',
									  'field' => 'id',
									  'terms' => $term->term_id, // Where term_id of Term 1 is "1".
									  'include_children' => false
									)
								  )
								));

								$classement .= '<table><thead><tr><th>'.__('Rang','asttq').'</th><th>'.__('Véhicule','asttq').'</th><th>'.__('Compétiteur','asttq').'</th><th>'.__('Distance','asttq').'</th><th>'.__('Points','asttq').'</th></tr></thead><tbody>';

								foreach($tireurs as $tireur){
									$vehicule = get_field('nom_du_vehicule', $tireur->ID);
									$classement .=  '<tr><td> - </td><td>'.$vehicule.'</td><td>'.$tireur->post_title.'</td><td> - </td><td> - </td></tr>';
								}

								$classement .= '</tbody></table>';
						}
					}		
					
					
					if(!empty($classementFinal)){
						$classement = $classementHeader.$classementFinal;
					}else{
						
						$classement = $classementHeader.$classement;
					}
			
					$classement .= '[/learn_more]';
					$classes .= '[/learn_more]';
					
					echo do_shortcode($classes.$classement);
					
			//$competitions = get_field('competition',$post->ID);
			//echo '<textarea style="widht:100%;height:650px;">'.print_r($competitions, true).'</textarea>';
				?>
			</div>
			<!-- .tribe-events-single-event-description -->
			<?php 
			
			do_action( 'tribe_events_single_event_after_the_content' );
			
			?>

			<!-- Event meta -->
			<?php do_action( 'tribe_events_single_event_before_the_meta' ) ?>
			<?php tribe_get_template_part( 'modules/meta' ); ?>
			<?php do_action( 'tribe_events_single_event_after_the_meta' ) ?>
		</div> <!-- #post-x -->
		<?php if ( get_post_type() == Tribe__Events__Main::POSTTYPE && tribe_get_option( 'showComments', false ) ) comments_template() ?>
	<?php endwhile; ?>

	<!-- Event footer -->
	<div id="tribe-events-footer">
		<!-- Navigation -->
		<h3 class="tribe-events-visuallyhidden"><?php printf( esc_html__( '%s Navigation', 'the-events-calendar' ), $events_label_singular ); ?></h3>
		<ul class="tribe-events-sub-nav">
			<li class="tribe-events-nav-previous"><?php tribe_the_prev_event_link( '<span>&laquo;</span> %title%' ) ?></li>
			<li class="tribe-events-nav-next"><?php tribe_the_next_event_link( '%title% <span>&raquo;</span>' ) ?></li>
		</ul>
		<!-- .tribe-events-sub-nav -->
	</div>
	<!-- #tribe-events-footer -->
	
	<script>
		jQuery(document).ready(function(){
			jQuery('.acf-true-false > label').each(function(){

				jQuery(this).addClass('switch');
				jQuery(this).append(jQuery('<div class="slider round"></div>'));
			});		
			
			<?php
			
			?>
			
		});
	</script>
	
<?php

	?>
</div><!-- #tribe-events-content -->
